"""그래프 경로 탐색 및 시각화."""
from __future__ import annotations

from src.graph.graph_store import GraphStore, path_status
from src.schemas import VERIFIED_STATUSES, Edge, NodeType

NODE_COLORS = {
    "COMPANY": "#2563eb", "INDUSTRY": "#16a34a", "PRODUCT": "#f59e0b", "TECHNOLOGY": "#7c3aed",
    "RESOURCE": "#0891b2", "EVENT": "#dc2626", "BOTTLENECK": "#be185d",
}
EDGE_STYLES = {
    "VERIFIED_FACT": {"dashes": False, "width": 3, "color": "#111827"},
    "SUPPORTED_INFERENCE": {"dashes": False, "width": 2, "color": "#6b7280"},
    "HYPOTHESIS": {"dashes": True, "width": 1, "color": "#9ca3af"},
    "INSUFFICIENT_EVIDENCE": {"dashes": [2, 6], "width": 1, "color": "#d1d5db"},
    "CONTRADICTED": {"dashes": True, "width": 1, "color": "#ef4444"},
}


def company_paths(gs: GraphStore, start: str, max_hops: int = 5, include_weak: bool = False
                  ) -> dict[str, list[list[Edge]]]:
    """start 노드에서 각 기업 노드까지의 단순 경로(순환 제외)."""
    out: dict[str, list[list[Edge]]] = {}

    def dfs(node: str, path: list[Edge], visited: set[str]) -> None:
        if len(path) >= max_hops:
            return
        for e in gs.out_edges(node, verified_only=not include_weak):
            if e.target_id in visited:
                continue  # 순환 경로 방지
            new = path + [e]
            if gs.g.nodes[e.target_id].get("node_type") == NodeType.COMPANY.value:
                out.setdefault(e.target_id, []).append(new)
            dfs(e.target_id, new, visited | {e.target_id})

    if start in gs.g:
        dfs(start, [], {start})
    return out


def describe_path(gs: GraphStore, path: list[Edge]) -> str:
    if not path:
        return ""
    names = [gs.g.nodes[path[0].source_id]["name"]]
    for e in path:
        names.append(f"-[{e.relationship.value}]-> {gs.g.nodes[e.target_id]['name']}")
    return " ".join(names) + f"  (경로 상태: {path_status(path).value})"


def to_pyvis_html(gs: GraphStore, height: str = "650px", include_weak: bool = True) -> str:
    from pyvis.network import Network

    net = Network(height=height, width="100%", directed=True, notebook=False, cdn_resources="in_line")
    used = set()
    for e in gs.edges():
        if not include_weak and e.verification_status not in VERIFIED_STATUSES:
            continue
        used |= {e.source_id, e.target_id}
    for nid in used:
        d = gs.g.nodes[nid]
        label = d["name"] + (f"\n({d['stock_code']})" if d.get("stock_code") else "")
        net.add_node(nid, label=label, color=NODE_COLORS.get(d["node_type"], "#999"),
                     title=f"{d['node_type']}: {d['name']}", shape="dot", size=18 if d["node_type"] == "COMPANY" else 12)
    for e in gs.edges():
        if e.source_id not in used or e.target_id not in used:
            continue
        if not include_weak and e.verification_status not in VERIFIED_STATUSES:
            continue
        style = EDGE_STYLES[e.verification_status.value]
        net.add_edge(e.source_id, e.target_id, label=e.relationship.value, title=f"{e.verification_status.value}\n{e.reasoning[:200]}",
                     arrows="to", **style)
    net.set_options('{"physics": {"stabilization": {"iterations": 150}}, "edges": {"font": {"size": 9}}}')
    return net.generate_html()

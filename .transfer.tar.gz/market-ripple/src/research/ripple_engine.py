"""Multi-hop Ripple Engine: 제한된 BFS 기반 산업 파급효과 탐색."""
from __future__ import annotations

import datetime as dt
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from src.discovery.entity_resolution import EntityResolver
from src.graph.graph_store import GraphStore, company_node_id, path_status
from src.graph.traversal import company_paths, describe_path
from src.llm import LLM, LLMBudgetExceeded, load_prompt
from src.research.event_extractor import extract_event
from src.research.query_generator import generate_queries
from src.research.relationship_extractor import extract_relations
from src.research.validator import RelationValidator, ValidationOutcome
from src.retrieval.retriever import BudgetExceeded, Retriever
from src.schemas import (STATUS_STRENGTH, VERIFIED_STATUSES, CandidateRelation, CompanyImpactList, Edge, Event,
                         EventType, Node, NodeType, RelationshipType, VerificationStatus)
from src.storage import Storage

log = logging.getLogger(__name__)

PREMISE_REL = {
    EventType.DEMAND_INCREASE: RelationshipType.INCREASES_DEMAND_FOR,
    EventType.DEMAND_DECREASE: RelationshipType.DECREASES_DEMAND_FOR,
    EventType.CAPACITY_EXPANSION: RelationshipType.INCREASES_DEMAND_FOR,
    EventType.SUPPLY_DISRUPTION: RelationshipType.CONSTRAINS,
    EventType.PRICE_INCREASE: RelationshipType.EXPOSED_TO,
    EventType.PRICE_DECREASE: RelationshipType.EXPOSED_TO,
}


@dataclass
class RippleConfig:
    max_hops: int = 3
    max_branches_per_hop: int = 3
    max_retrieval_calls: int = 20
    max_llm_calls: int = 25
    top_k: int = 5
    queries_per_node: int = 2
    max_relations_per_node: int = 6
    as_of_date: str | None = None
    use_existing_graph: bool = True


@dataclass
class RippleResult:
    run_id: str
    input_text: str
    event: dict
    event_warnings: list[str]
    graph: dict
    company_results: list[dict]
    summary: str
    rejected: list[dict]
    progress: list[str]
    budget: dict
    elapsed_ms: int
    stopped_reason: str
    as_of_date: str | None
    used_chunk_ids: list[int] = field(default_factory=list)

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class RippleEngine:
    def __init__(self, storage: Storage, llm: LLM, retriever: Retriever, resolver: EntityResolver,
                 config: RippleConfig, base_graph: GraphStore | None = None,
                 progress_cb: Callable[[str], None] | None = None,
                 company_expander: Callable[[dict], bool] | None = None):
        self.storage = storage
        self.llm = llm
        self.retriever = retriever
        self.resolver = resolver
        self.cfg = config
        self.base_graph = base_graph if config.use_existing_graph and not config.as_of_date else None
        self.progress_cb = progress_cb
        self.company_expander = company_expander
        self.validator = RelationValidator(storage, llm, resolver.as_dict_resolver(), config.as_of_date)
        self.progress: list[str] = []

    def _p(self, msg: str) -> None:
        self.progress.append(msg)
        log.info(msg)
        if self.progress_cb:
            self.progress_cb(msg)

    # ------------------------------------------------------------------
    def _node_for(self, gs: GraphStore, name: str, ntype: NodeType, outcome: ValidationOutcome | None,
                  side: str) -> str | None:
        if ntype == NodeType.COMPANY:
            comp = getattr(outcome, f"{side}_company", None) if outcome else None
            if comp is None:
                r, _ = self.resolver.resolve(name)
                comp = r.to_dict() if r else None
            if comp is None:
                return None
            return gs.ensure_company_node(comp["corp_name"], comp["stock_code"], comp["corp_code"])
        return gs.ensure_concept_node(name, ntype)

    def _add_outcome(self, gs: GraphStore, o: ValidationOutcome, hop: int, today: str) -> Edge | None:
        c = o.candidate
        src = self._node_for(gs, c.source_name, c.source_type, o, "source")
        tgt = self._node_for(gs, c.target_name, c.target_type, o, "target")
        if not src or not tgt or src == tgt:
            return None
        edge = Edge(edge_id=f"edge_{uuid.uuid4().hex[:10]}", source_id=src, target_id=tgt,
                    relationship=c.relationship,
                    claim_type=c.claim_type if o.status != VerificationStatus.VERIFIED_FACT else "FACT",
                    verification_status=o.status, evidence=o.evidence, conditions=o.conditions,
                    reasoning=c.reasoning + (f" | 검증 메모: {'; '.join(o.reasons)}" if o.reasons else ""),
                    created_at=today, as_of_date=self.cfg.as_of_date, hop=hop)
        gs.add_edge(edge)
        return edge

    def _seed_graph(self, gs: GraphStore) -> None:
        if self.base_graph is None:
            return
        for nid, d in self.base_graph.g.nodes(data=True):
            gs.add_node(Node(**d))
        for e in self.base_graph.edges(VERIFIED_STATUSES):
            gs.add_edge(e)

    # ------------------------------------------------------------------
    def run(self, input_text: str, seed: dict) -> RippleResult:
        t0 = time.time()
        run_id = dt.datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        today = (self.cfg.as_of_date or dt.date.today().isoformat())
        self.llm.reset_budget(self.cfg.max_llm_calls)
        self.retriever.reset_budget(self.cfg.max_retrieval_calls)
        gs = GraphStore()
        self._seed_graph(gs)
        rejected: list[dict] = []
        used_queries: list[str] = []
        used_chunks: set[int] = set()
        stopped = "탐색 완료"

        # 1. 이벤트 구조화
        self._p("이벤트 구조화 중")
        event, warnings = extract_event(self.llm, input_text, self.resolver)
        for w in warnings:
            self._p(f"⚠ {w}")
        event_node = gs.add_node(Node(node_id=f"event_{run_id}", node_type=NodeType.EVENT,
                                      name=event.summary[:60] or "입력 이벤트"))
        seed_node = gs.ensure_company_node(seed["corp_name"], seed["stock_code"], seed["corp_code"])
        roots = [seed_node]
        premise_rel = PREMISE_REL.get(event.event_type, RelationshipType.EXPOSED_TO)
        for name, t in [(p, NodeType.PRODUCT) for p in event.products] + [(i, NodeType.INDUSTRY) for i in event.industries]:
            roots.append(gs.ensure_concept_node(name, t))
        roots += [nid for nid in event.entity_ids if nid in gs.g]
        roots = list(dict.fromkeys(roots))
        for r in roots:
            # 사용자 입력 전제 (근거 검증 대상이 아님, hop=0)
            gs.add_edge(Edge(edge_id=f"premise_{uuid.uuid4().hex[:8]}", source_id=event_node, target_id=r,
                             relationship=premise_rel, claim_type="HYPOTHESIS",
                             verification_status=VerificationStatus.HYPOTHESIS,
                             reasoning="사용자 입력 이벤트 전제 (검증 대상 아님)", created_at=today,
                             as_of_date=self.cfg.as_of_date, hop=0))

        # 2. BFS
        frontier = [(r, 1) for r in roots[: max(self.cfg.max_branches_per_hop, 1) + 1]]
        visited: set[str] = {event_node}
        try:
            while frontier:
                node_id, hop = frontier.pop(0)
                if node_id in visited:
                    continue  # 순환 감지
                visited.add(node_id)
                if hop > self.cfg.max_hops:
                    continue
                nd = gs.g.nodes[node_id]
                self._p(f"[Hop {hop}] {nd['name']} ({nd['node_type']}) 탐색")
                next_nodes: list[tuple[str, int]] = []

                # 2-1. 기존 검증 그래프 우선
                for e in gs.out_edges(node_id, verified_only=True):
                    if e.hop != 0 and e.target_id not in visited:
                        next_nodes.append((e.target_id, STATUS_STRENGTH[e.verification_status]))

                # 2-2. 부족하면 RAG + LLM 확장
                if len(next_nodes) < self.cfg.max_branches_per_hop:
                    queries = generate_queries(self.llm, self.storage, nd["name"], nd["node_type"], event.summary,
                                               used_queries, self.cfg.queries_per_node)
                    results = []
                    corp_filter = [nd["corp_code"]] if nd.get("corp_code") and hop == 1 and node_id == seed_node else None
                    for q in queries:
                        used_queries.append(q)
                        results += self.retriever.search(q, top_k=self.cfg.top_k, as_of_date=self.cfg.as_of_date,
                                                         corp_codes=corp_filter)
                    uniq = list({r.chunk_id: r for r in results}.values())
                    used_chunks |= {r.chunk_id for r in uniq}
                    self._p(f"  검색 {len(queries)}건 → Chunk {len(uniq)}개")
                    cands = extract_relations(self.llm, nd["name"], event.summary, uniq,
                                              self.cfg.max_relations_per_node)
                    self._p(f"  관계 후보 {len(cands)}개 추출")
                    for c in cands:
                        o = self.validator.validate(c)
                        if o.status == VerificationStatus.CONTRADICTED:
                            rejected.append(o.to_dict())
                            self._p(f"  ✗ 반박됨: {c.source_name} -{c.relationship.value}-> {c.target_name}")
                            continue
                        edge = self._add_outcome(gs, o, hop, today)
                        if edge is None:
                            rejected.append({**o.to_dict(), "reasons": o.reasons + ["노드 식별 실패"]})
                            continue
                        mark = "✓" if o.status in VERIFIED_STATUSES else "?"
                        self._p(f"  {mark} {c.source_name} -{c.relationship.value}-> {c.target_name} [{o.status.value}]")
                        # 검증 실패(가설/근거부족) 관계는 확장하지 않는다
                        if o.status in VERIFIED_STATUSES:
                            nxt = edge.target_id if edge.source_id == node_id else (
                                edge.source_id if edge.target_id == node_id else edge.target_id)
                            if nxt not in visited:
                                next_nodes.append((nxt, STATUS_STRENGTH[o.status]))
                            self._maybe_expand_company(gs, nxt)
                # 강한 근거 순으로 최대 N개 분기
                seen_next = []
                for nid, _ in sorted(next_nodes, key=lambda x: -x[1]):
                    if nid not in seen_next:
                        seen_next.append(nid)
                for nid in seen_next[: self.cfg.max_branches_per_hop]:
                    if hop + 1 <= self.cfg.max_hops:
                        frontier.append((nid, hop + 1))
        except (LLMBudgetExceeded, BudgetExceeded) as exc:
            stopped = f"예산 소진으로 중단: {exc}"
            self._p(f"⚠ {stopped}")

        # 3. 기업별 결과
        company_results, summary = self._company_results(gs, roots, event)
        result = RippleResult(
            run_id=run_id, input_text=input_text, event=event.model_dump(mode="json"), event_warnings=warnings,
            graph=gs.to_dict(), company_results=company_results, summary=summary, rejected=rejected,
            progress=self.progress, elapsed_ms=int((time.time() - t0) * 1000), stopped_reason=stopped,
            as_of_date=self.cfg.as_of_date, used_chunk_ids=sorted(used_chunks),
            budget={"llm": self.llm.usage.to_dict(), "retrieval_calls": self.retriever.calls,
                    "retrieval_cache_hits": self.retriever.cache_hits,
                    "limits": {"llm": self.cfg.max_llm_calls, "retrieval": self.cfg.max_retrieval_calls}})
        return result

    def _maybe_expand_company(self, gs: GraphStore, node_id: str) -> None:
        if self.company_expander is None or self.cfg.as_of_date:
            return
        d = gs.g.nodes[node_id]
        if d.get("node_type") != NodeType.COMPANY.value or not d.get("corp_code"):
            return
        if self.storage.get_company(d["corp_code"]) and self.storage.get_company(d["corp_code"])["ingestion_status"] == "READY":
            return
        try:
            if self.company_expander(d):
                self._p(f"  + 신규 기업 공시 수집: {d['name']}")
        except Exception as exc:
            self._p(f"  ⚠ 신규 기업 수집 실패 ({d['name']}): {exc}")

    # ------------------------------------------------------------------
    def _company_results(self, gs: GraphStore, roots: list[str], event: Event) -> tuple[list[dict], str]:
        paths: dict[str, list[list[Edge]]] = {}
        for r in roots:
            if gs.g.nodes[r].get("node_type") == NodeType.COMPANY.value:
                paths.setdefault(r, []).append([])  # 루트 자체가 기업 (직접 연결)
            for cid, ps in company_paths(gs, r, self.cfg.max_hops + 1, include_weak=True).items():
                paths.setdefault(cid, []).extend(ps)
        rows = []
        for cid, ps in paths.items():
            d = gs.g.nodes[cid]
            ps = sorted(ps, key=lambda p: (-STATUS_STRENGTH[path_status(p)] if p else -5, len(p)))
            best = ps[0]
            evidence = [ev.model_dump() for e in best for ev in e.evidence]
            rows.append({
                "node_id": cid, "corp_name": d["name"], "stock_code": d.get("stock_code"), "corp_code": d.get("corp_code"),
                "path": describe_path(gs, best) if best else "(이벤트 직접 연결 기업)",
                "path_edge_ids": [e.edge_id for e in best], "hops": len(best),
                "relationship_types": [e.relationship.value for e in best],
                "impact_scope": "DIRECT" if len(best) <= 1 else "INDIRECT",
                "verification_status": path_status(best).value if best else "PREMISE",
                "evidence": evidence, "n_paths": len(ps),
            })
        rows.sort(key=lambda r: (-STATUS_STRENGTH.get(VerificationStatus(r["verification_status"]), 5)
                                 if r["verification_status"] != "PREMISE" else -5, r["hops"]))
        summary = ""
        try:
            summary = self._impact_analysis(gs, rows, event)
        except (LLMBudgetExceeded, BudgetExceeded) as exc:
            summary = f"(LLM 예산 소진으로 기업별 영향 분석을 생성하지 못했습니다: {exc})"
            for r in rows:
                r.update(economic_impact="UNCERTAIN", revenue_exposure="UNKNOWN", conditions=[], counter_scenario="",
                         technical_relevance="")
        return rows, summary

    def _impact_analysis(self, gs: GraphStore, rows: list[dict], event: Event) -> str:
        if not rows:
            return "근거로 연결된 기업을 찾지 못했습니다."
        lines = [f"이벤트: {event.summary} (유형: {event.event_type.value}, 가상 시나리오: {event.is_hypothetical})"]
        allowed_chunks: dict[str, set[int]] = {}
        for r in rows:
            lines.append(f"\n## {r['corp_name']} ({r['stock_code']}) - 경로: {r['path']}")
            allowed_chunks[r["corp_name"]] = {e["chunk_id"] for e in r["evidence"]}
            for ev in r["evidence"][:4]:
                ch = self.storage.get_chunk(ev["chunk_id"])
                lines.append(f"- [chunk {ev['chunk_id']}] 인용: {ev['quote']}")
                if ch:
                    lines.append(f"  (원문 일부: {ch['raw_text'][:400]})")
        out: CompanyImpactList = self.llm.parse(load_prompt("verification", "impact"), "\n".join(lines),
                                                CompanyImpactList, purpose="impact_analysis")
        by_name = {c.corp_name: c for c in out.companies}
        for r in rows:
            c = by_name.get(r["corp_name"])
            if c is None:
                r.update(economic_impact="UNCERTAIN", revenue_exposure="UNKNOWN", conditions=[], counter_scenario="",
                         technical_relevance="", cited_chunk_ids=[])
                continue
            cited = [i for i in c.cited_chunk_ids if i in allowed_chunks.get(r["corp_name"], set())]
            exposure = c.revenue_exposure if cited else "UNKNOWN"  # 근거 없는 매출 노출도는 UNKNOWN
            r.update(economic_impact=c.economic_impact, conditions=c.conditions, counter_scenario=c.counter_scenario,
                     technical_relevance=c.technical_relevance, revenue_exposure=exposure, cited_chunk_ids=cited)
        return out.summary


def save_result(result: RippleResult, runs_dir: Path, storage: Storage, model: str, config: dict) -> Path:
    runs_dir.mkdir(parents=True, exist_ok=True)
    p = runs_dir / f"{result.run_id}.json"
    p.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    storage.save_run(run_id=result.run_id, input_text=result.input_text, seed_stock_code=config.get("seed_stock_code"),
                     as_of_date=result.as_of_date, model=model, configuration_json=json.dumps(config, ensure_ascii=False, default=str),
                     result_path=str(p), elapsed_ms=result.elapsed_ms,
                     token_usage_json=json.dumps(result.budget, ensure_ascii=False),
                     status="COMPLETED" if result.stopped_reason == "탐색 완료" else "PARTIAL")
    return p

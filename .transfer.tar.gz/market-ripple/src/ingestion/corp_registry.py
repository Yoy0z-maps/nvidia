"""기업 고유번호 사전 및 상장 시장 확인."""
from __future__ import annotations

import json
import logging
import re
import unicodedata
from pathlib import Path

from lxml import etree

from src.schemas import CorpInfo

log = logging.getLogger(__name__)

MARKET_BY_CLS = {"Y": "KOSPI", "K": "KOSDAQ", "N": "KONEX", "E": "OTHER"}

_SUFFIX_RE = re.compile(r"(주식회사|\(주\)|㈜|\(株\)|co\.?,?\s*ltd\.?|corporation|corp\.?|inc\.?)", re.I)


def normalize_name(name: str) -> str:
    """기업명 정규화: 유니코드 NFKC, 법인 표기 제거, 공백/기호 제거, 소문자."""
    s = unicodedata.normalize("NFKC", name or "")
    s = _SUFFIX_RE.sub("", s)
    s = re.sub(r"[\s\.\,\-·&'\"()]", "", s)
    return s.lower()


def parse_corp_code_xml(xml_bytes: bytes) -> list[CorpInfo]:
    root = etree.fromstring(xml_bytes, parser=etree.XMLParser(recover=True, huge_tree=True))
    out: list[CorpInfo] = []
    for el in root.iter("list"):
        code = (el.findtext("corp_code") or "").strip()
        if not code:
            continue
        out.append(CorpInfo(
            corp_code=code.zfill(8),
            corp_name=(el.findtext("corp_name") or "").strip(),
            stock_code=(el.findtext("stock_code") or "").strip(),
            modify_date=(el.findtext("modify_date") or "").strip(),
        ))
    return out


class CorpRegistry:
    """전체 기업 사전은 로컬 JSON으로 캐싱한다 (기업 정보만 저장)."""

    def __init__(self, corps: list[CorpInfo]):
        self.corps = corps
        self.by_code = {c.corp_code: c for c in corps}
        self.by_stock = {c.stock_code: c for c in corps if c.stock_code}
        self._by_norm: dict[str, list[CorpInfo]] = {}
        for c in corps:
            self._by_norm.setdefault(normalize_name(c.corp_name), []).append(c)

    # ---- 로딩 ----
    @classmethod
    def load_or_download(cls, cache_path: Path, dart_client=None, refresh: bool = False) -> "CorpRegistry":
        if cache_path.exists() and not refresh:
            data = json.loads(cache_path.read_text(encoding="utf-8"))
            return cls([CorpInfo(**d) for d in data["corps"]])
        if dart_client is None:
            raise RuntimeError("기업 사전 캐시가 없고 DART 클라이언트도 없습니다.")
        xml_bytes = dart_client.download_corp_codes()
        corps = parse_corp_code_xml(xml_bytes)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps({"count": len(corps), "corps": [c.model_dump() for c in corps]},
                                         ensure_ascii=False), encoding="utf-8")
        log.info("기업 고유번호 사전 저장: %d개 (종목코드 보유 %d개)", len(corps),
                 sum(1 for c in corps if c.stock_code))
        return cls(corps)

    # ---- 검색 ----
    def get_by_stock_code(self, stock_code: str) -> CorpInfo | None:
        return self.by_stock.get(stock_code.zfill(6))

    def resolve_name(self, name: str, listed_only: bool = True) -> tuple[CorpInfo | None, str]:
        """기업명 → CorpInfo. 정확히 식별할 수 없으면 (None, 사유)."""
        norm = normalize_name(name)
        if not norm:
            return None, "빈 기업명"
        exact = [c for c in self._by_norm.get(norm, []) if c.stock_code or not listed_only]
        if len(exact) == 1:
            return exact[0], "정규화 명칭 정확 일치"
        if len(exact) > 1:
            return None, f"동일 명칭 기업 {len(exact)}개 - 모호함"
        # 부분 일치는 유일할 때만 허용 (예: '한미반도체' ⊂ '한미반도체주식회사')
        partial = [c for k, cs in self._by_norm.items() if norm in k or (len(k) >= 3 and k in norm)
                   for c in cs if c.stock_code or not listed_only]
        if len(partial) == 1:
            return partial[0], "유일한 부분 일치"
        if len(partial) > 1:
            return None, f"부분 일치 후보 {len(partial)}개 - 모호함: " + ", ".join(c.corp_name for c in partial[:5])
        return None, "기업 사전에 없음"


class MarketTypeResolver:
    """OpenDART company.json의 corp_cls로 KOSPI/KOSDAQ 상장 여부를 확인한다 (캐싱)."""

    def __init__(self, dart_client, storage):
        self.dart = dart_client
        self.storage = storage

    def market_type(self, corp_code: str) -> str | None:
        cached = self.storage.cache_get("market_type", corp_code)
        if cached is not None:
            return cached
        info = self.dart.company_info(corp_code)
        market = MARKET_BY_CLS.get(info.get("corp_cls", ""), None)
        self.storage.cache_set("market_type", corp_code, market)
        return market

    def is_kospi_or_kosdaq(self, corp_code: str) -> bool:
        return self.market_type(corp_code) in {"KOSPI", "KOSDAQ"}

"""이벤트 파급효과 분석.

uv run python -m scripts.run_research --seed 000660 --query "HBM 수요가 증가할 경우 ..."
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config.settings import Settings, setup_logging  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed")
    ap.add_argument("--query", required=True)
    ap.add_argument("--hops", type=int, help="분석 Hop (기본 3, 최대 5)")
    ap.add_argument("--as-of", help="YYYY-MM-DD: 해당 날짜까지 공개된 문서만 사용")
    ap.add_argument("--financial", action="store_true", help="결과 기업에 대해 MCP 금융 분석 실행")
    ap.add_argument("--event-date", help="금융 분석 기준일 (기본: 이벤트 추출 날짜 또는 오늘)")
    ap.add_argument("--expand-companies", action="store_true", help="새로 발견된 기업 공시 추가 수집 (기업 수 제한 적용)")
    args = ap.parse_args()

    s = Settings.from_env()
    if args.seed:
        s.seed_stock_code = args.seed.zfill(6)
    if args.hops:
        s.max_analysis_hops = args.hops
        s.validate()
    setup_logging(s)

    from src.pipeline import build_app, make_ingest_fn, seed_company
    from src.research.ripple_engine import RippleConfig, RippleEngine, save_result

    app = build_app(s, need_dart=bool(s.dart_api_key))
    app.llm.check_model()
    seed = seed_company(app)
    expander = None
    if args.expand_companies and app.collector is not None:
        ingest = make_ingest_fn(app, print)

        def expander(node: dict) -> bool:
            ready = sum(1 for c in app.storage.list_companies() if c["ingestion_status"] == "READY")
            if ready >= s.max_companies:
                return False
            r, _ = app.resolver.resolve(node["name"])
            return bool(r) and ingest(r, 99, seed["corp_code"], "ripple 확장")

    cfg = RippleConfig(max_hops=s.max_analysis_hops, max_branches_per_hop=s.max_branches_per_hop,
                       max_retrieval_calls=s.max_retrieval_calls, max_llm_calls=s.max_llm_calls,
                       top_k=s.retrieval_top_k, as_of_date=args.as_of)
    engine = RippleEngine(app.storage, app.llm, app.retriever, app.resolver, cfg,
                          base_graph=app.load_graph(), progress_cb=print, company_expander=expander)
    res = engine.run(args.query, seed)
    path = save_result(res, s.runs_dir, app.storage, s.llm_model, {**s.public_dict(), **cfg.__dict__})

    print("\n=== 이벤트 ===")
    print(json.dumps(res.event, ensure_ascii=False, indent=2))
    print("\n=== 요약 ===\n" + res.summary)
    print("\n=== 기업별 결과 ===")
    for r in res.company_results:
        print(f"- {r['corp_name']}({r['stock_code']}) [{r['verification_status']}] {r.get('economic_impact', '')}"
              f"\n    경로: {r['path']}\n    매출 노출도: {r.get('revenue_exposure', 'UNKNOWN')}")
    print(f"\n중단 사유: {res.stopped_reason} / LLM {res.budget['llm']['calls']}회, 검색 {res.budget['retrieval_calls']}회, "
          f"{res.elapsed_ms / 1000:.1f}s")

    if args.financial:
        from src.financial.analysis import analyze, default_providers
        ev_date = args.event_date or res.event.get("event_date") or dt.date.today().isoformat()
        comps = []
        for r in res.company_results:
            c = app.storage.get_company(r["corp_code"]) if r.get("corp_code") else None
            mt = (c or {}).get("market_type") or (app.market.market_type(r["corp_code"]) if app.market and r.get("corp_code") else None)
            comps.append({"stock_code": r["stock_code"], "corp_name": r["corp_name"], "market_type": mt})
        fin = analyze(comps, ev_date, *default_providers(s))
        res_d = json.loads(path.read_text(encoding="utf-8"))
        res_d["financial"] = fin
        path.write_text(json.dumps(res_d, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        print("\n=== 금융 분석 상태 ===")
        print(json.dumps(fin["status"], ensure_ascii=False, indent=2, default=str))
    print(f"\n결과 저장: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
